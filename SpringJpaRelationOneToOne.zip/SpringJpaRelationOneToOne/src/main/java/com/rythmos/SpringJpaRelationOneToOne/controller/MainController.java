package com.rythmos.SpringJpaRelationOneToOne.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rythmos.SpringJpaRelationOneToOne.Dao.LaptopRepo;
import com.rythmos.SpringJpaRelationOneToOne.Dao.PersonRepo;
import com.rythmos.SpringJpaRelationOneToOne.model.Laptop;
import com.rythmos.SpringJpaRelationOneToOne.model.Person;

@RestController
public class MainController
{
@Autowired
private PersonRepo personRepo;
@Autowired
private LaptopRepo laptopRepo;

@GetMapping("/save")
public Person save(@RequestBody Person p)
{
	return personRepo.save(p);
}
}
//{
//    "id": 472,
//    "name": "Vamsi",
//    "designation": "consultant",
//    "laptop": {
//        "laptopName": "Dell",
//        "lid": 4
//    }
//}