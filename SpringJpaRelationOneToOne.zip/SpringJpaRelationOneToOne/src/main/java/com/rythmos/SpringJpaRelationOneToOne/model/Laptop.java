package com.rythmos.SpringJpaRelationOneToOne.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Laptop
{
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private int Lid;
private String laptopName;

public int getLid() {
	return Lid;
}
public void setLid(int lid) {
	Lid = lid;
}
public String getLaptopName() {
	return laptopName;
}
public void setLaptopName(String laptopName) {
	this.laptopName = laptopName;
}

}
