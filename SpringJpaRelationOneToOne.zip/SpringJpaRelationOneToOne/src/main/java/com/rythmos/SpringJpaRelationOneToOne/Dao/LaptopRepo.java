package com.rythmos.SpringJpaRelationOneToOne.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rythmos.SpringJpaRelationOneToOne.model.Laptop;

public interface LaptopRepo extends JpaRepository<Laptop,Integer>{

}
