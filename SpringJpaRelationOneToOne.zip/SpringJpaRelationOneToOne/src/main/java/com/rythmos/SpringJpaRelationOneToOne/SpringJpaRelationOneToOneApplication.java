package com.rythmos.SpringJpaRelationOneToOne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaRelationOneToOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaRelationOneToOneApplication.class, args);
	}

}
