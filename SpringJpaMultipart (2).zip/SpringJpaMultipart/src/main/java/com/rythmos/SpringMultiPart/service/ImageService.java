package com.rythmos.SpringMultiPart.service;

import java.io.IOException;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.rythmos.SpringMultiPart.Dao.ImageRepo;
import com.rythmos.SpringMultiPart.model.Image;

@Service
public class ImageService
{
	@Autowired
	private ImageRepo imageRepo;
	
	@Autowired
	private Image Img;

	public Image store(Image Img,MultipartFile file) throws IOException {
	    String fileName = StringUtils.cleanPath(file.getOriginalFilename());
//	    Image Img=new Image();
	    Img.setName(fileName);
	    Img.setType(file.getContentType());
	    Img.setData(file.getBytes());
	    return imageRepo.save(Img);
	  }

	  public Image getFile(Integer id) {
	    return imageRepo.getOne(id);
	  }
	  public Stream<Image> getAllFiles() {
		    return imageRepo.findAll().stream();
		  }
}
