package com.rythmos.SpringMultiPart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rythmos.SpringMultiPart.Dao.ImageRepo;
import com.rythmos.SpringMultiPart.Dao.Repo;
import com.rythmos.SpringMultiPart.model.Employee;
import com.rythmos.SpringMultiPart.model.Image;
import com.rythmos.SpringMultiPart.service.ImageService;

@RestController
public class Controller1 
{
	@Autowired
	private ImageService imageService;
	
	@Autowired
	private Image img;
	
	@Autowired
	private Repo repo;
	
	@PostMapping("/upload")
	  public String uploadFile(@RequestParam("file") MultipartFile file,@RequestParam("img") String img) {
	    String message = "";
	    ObjectMapper obj=new ObjectMapper();
	    //String json=img;
	    Image i=null;
		try {
			i = obj.readValue(img,Image.class);
		} catch (JsonMappingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (JsonProcessingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//	    img.setpName("Vamsi");
//	    img.setEmail("brugumallavamsi@gmail.com");
//	    img.setPhoneNumber(7386243143l);
	    try {
	    	imageService.store(i,file);

	      message = "Uploaded the file successfully: " + file.getOriginalFilename();
	      return message;
	    } catch (Exception e) {
	      message = "Could not upload the file: " + file.getOriginalFilename() + "!";
	      return message;
	    }
	  }
	@GetMapping("/files/{id}")
	  public byte[] getFile(@PathVariable Integer id) {
	    Image fileDB = imageService.getFile(id);
	    return fileDB.getData();
	}
	
	@PostMapping("/save")
	public String insert1(@RequestBody Employee emp) {
		repo.save(emp);
		return "Saved Sucessfully";
	}
	
	@GetMapping("/getbyname/{name}")
	public List<Employee> getByName(@PathVariable String name) {
		return repo.findByName(name);
	}
	
	@GetMapping("/getbymobile/{mobileNumber}")
	public List<Employee> getByMobile(@PathVariable long mobileNumber) {
		return repo.findByMobileNumber(mobileNumber);
	}
	
	@GetMapping("/getbynameandpassword/{name}/{password}")
	public List<Employee> insert(@PathVariable String name,@PathVariable String password) {
		return repo.findByNameAndPassword(name,password);
	}
}
