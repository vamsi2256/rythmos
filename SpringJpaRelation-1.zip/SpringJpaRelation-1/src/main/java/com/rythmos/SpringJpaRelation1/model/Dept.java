package com.rythmos.SpringJpaRelation1.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@Component
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
public class Dept
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int dept_id;
	private String deptName;
	@JsonManagedReference
	@OneToMany(mappedBy = "dept",cascade = CascadeType.ALL)
	private Set<Emp> emp;
	public int getDept_id() {
		return dept_id;
	}
	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public Set<Emp> getEmp() {
		return emp;
	}
	public void setEmp(Set<Emp> emp) {
		this.emp = emp;
	}
	
	
}
//{
//    "dept_id": 1,
//    "deptName": "ece",
//    "emp": [
//        {
//            "id": "ryth0473",
//            "name": "nitish",
//            "phoneNumber": 7386243145
//        },
//        {
//            "id": "ryth0472",
//            "name": "vamsi",
//            "phoneNumber": 7386243143
//        },
//        {
//            "id": "ryth0474",
//            "name": "salmon",
//            "phoneNumber": 7386243144
//        }
//    ]
//}
