package com.rythmos.SpringJpaRelation1.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rythmos.SpringJpaRelation1.model.Dept;

public interface DeptRepo extends JpaRepository<Dept,Integer>{

}
