package com.rythmos.SpringJpaRelation1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaRelation1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaRelation1Application.class, args);
	}

}
