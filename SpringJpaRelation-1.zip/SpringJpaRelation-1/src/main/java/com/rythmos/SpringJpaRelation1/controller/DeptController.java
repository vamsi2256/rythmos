package com.rythmos.SpringJpaRelation1.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rythmos.SpringJpaRelation1.Dao.DeptRepo;
import com.rythmos.SpringJpaRelation1.Dao.EmpRepo;
import com.rythmos.SpringJpaRelation1.model.Dept;
import com.rythmos.SpringJpaRelation1.model.Emp;

@RestController
public class DeptController
{
@Autowired
private EmpRepo empRepo;
@Autowired
private DeptRepo deptRepo;
@Autowired
private Dept dept;
@Autowired
private Emp emp;

@PostMapping("/save")
public Dept insert(@RequestBody Dept dept) {
	return deptRepo.save(dept);
}
@GetMapping("/getdata/{id}")
public Dept getData(@PathVariable int id)
{
	return deptRepo.findById(id).get();
}
@PostMapping("/emp")
public Emp insert1(@RequestBody Emp emp) {
	return empRepo.save(emp);
}
}
