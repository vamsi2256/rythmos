package com.rythmos.SpringJpaAllRelation.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Laptop
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator = "lapi_seq")
	@SequenceGenerator(name = "lapi_seq",allocationSize = 1,initialValue = 1)
	private int lapiId;
	private String lapiName;
	public int getLapiId() {
		return lapiId;
	}
	public void setLapiId(int lapiId) {
		this.lapiId = lapiId;
	}
	public String getLapiName() {
		return lapiName;
	}
	public void setLapiName(String lapiName) {
		this.lapiName = lapiName;
	}
}

