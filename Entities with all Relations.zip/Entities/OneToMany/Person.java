package com.rythmos.SpringJpaAllRelation.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Person 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator = "person_seq")
	@SequenceGenerator(name = "person_seq",allocationSize = 1,initialValue = 1)
	private int id;
	private String name;
	private String dept;
	private long mobileNumber;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "per_lapi_id")
	private List<Laptop> lapi;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public List<Laptop> getLapi() {
		return lapi;
	}
	public void setLapi(List<Laptop> lapi) {
		this.lapi = lapi;
	}
	
}
