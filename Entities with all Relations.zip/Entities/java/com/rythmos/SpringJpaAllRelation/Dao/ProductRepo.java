package com.rythmos.SpringJpaAllRelation.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rythmos.SpringJpaAllRelation.model.Product;

public interface ProductRepo extends JpaRepository<Product,Integer>{

}
