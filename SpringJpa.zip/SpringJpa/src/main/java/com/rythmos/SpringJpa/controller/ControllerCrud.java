package com.rythmos.SpringJpa.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.rythmos.SpringJpa.model.Employee;
import com.rythmos.SpringJpa.model.EmployeeDTO;
import com.rythmos.SpringJpa.repo.EmployeeRepo;


@RestController
public class ControllerCrud 
{

	@Autowired
	public EmployeeRepo employeeRepo;
	
	@RequestMapping("/delete/{id}")
	public String delete(@PathVariable Integer id)
	{
		employeeRepo.deleteById(id);
		return "Deleted";
	}
	
	@PostMapping("/save")
	public String insert(@RequestBody Employee employee)
	{
		employeeRepo.save(employee);
		return "Employee Saved";
				
	}
	@PutMapping("/updatedto")
	public String updateDto(@RequestBody EmployeeDTO e)
	{
		Employee obj=employeeRepo.getOne(e.getId());
		obj.setName(e.getName());
		obj.setMobileNumber(e.getMobileNumber());
		obj.setEmail(e.getEmail());
		obj.setPassword(e.getPassword());
		employeeRepo.save(obj);
		return "Employee Updated";
	}
	@PostMapping("/getdata")
	public List<Employee> getEmployees()
	{
		List<Employee> list=employeeRepo.findAll();
		return list;
	}
}
