package com.rythmos.SpringJpaAllRelation.Dao;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.rythmos.SpringJpaAllRelation.Dto.CustomerDto;
import com.rythmos.SpringJpaAllRelation.model.Customer;

public interface CustomerRepo extends JpaRepository<Customer,Integer> 
{

	@Query(value = "select id from customer where id in(select customer_id from customer_products)",nativeQuery = true)
	public List<Integer> getData();
	
	@Query(value = "select id from customer where id not in(select customer_id from customer_products)",nativeQuery = true)
	public List<Integer> getNotData();
	
	@Query(value = "select id from product where id not in(select products_id from customer_products)",nativeQuery = true)
	public List<Integer> getNotSelledProducts();

	public Customer findByMobileNumber(long mobileNumber);

}
