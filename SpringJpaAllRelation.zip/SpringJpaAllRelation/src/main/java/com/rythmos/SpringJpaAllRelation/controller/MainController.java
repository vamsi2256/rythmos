package com.rythmos.SpringJpaAllRelation.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rythmos.SpringJpaAllRelation.Dao.CustomerRepo;
import com.rythmos.SpringJpaAllRelation.Dao.LaptopRepo;
import com.rythmos.SpringJpaAllRelation.Dao.PersonRepo;
import com.rythmos.SpringJpaAllRelation.Dto.CustomerDto;
import com.rythmos.SpringJpaAllRelation.model.Customer;
import com.rythmos.SpringJpaAllRelation.model.Laptop;
import com.rythmos.SpringJpaAllRelation.model.Person;

@RestController
public class MainController 
{
@Autowired
private PersonRepo personRepo;
@Autowired
private LaptopRepo laptopRepo;
@Autowired
private CustomerRepo customerRepo;

@PostMapping("/save")
public Person save(@RequestBody Person p)
{
	return personRepo.save(p);
}
@PostMapping("/save1")
public Laptop save(@RequestBody Laptop p)
{
	return laptopRepo.save(p);
}
@PostMapping("/save2")
public Customer save(@RequestBody Customer p)
{
//	Customer c=customerRepo.findByMobileNumber(p.getMobileNumber()); 
	return customerRepo.save(p);
}
@GetMapping("/getMatchCustomer")
public List<Integer> getMatch()
{
	return customerRepo.getData();
}
@GetMapping("/getNotMatchCustomer")
public List<Integer> getNotMatch()
{
	return customerRepo.getNotData();
}
@GetMapping("/getNotSelledProducts")
public List<Integer> getNotSelledProducts()
{
	return customerRepo.getNotSelledProducts();
}

}
