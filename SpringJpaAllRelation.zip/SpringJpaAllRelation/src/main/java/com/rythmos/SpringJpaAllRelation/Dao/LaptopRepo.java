package com.rythmos.SpringJpaAllRelation.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rythmos.SpringJpaAllRelation.model.Laptop;

public interface LaptopRepo extends JpaRepository<Laptop,Integer> {

}
