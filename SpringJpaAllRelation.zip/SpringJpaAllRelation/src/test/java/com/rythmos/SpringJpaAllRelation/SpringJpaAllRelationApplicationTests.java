package com.rythmos.SpringJpaAllRelation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaAllRelationApplicationTests {

	@Test
	void contextLoads() {
	}

}
