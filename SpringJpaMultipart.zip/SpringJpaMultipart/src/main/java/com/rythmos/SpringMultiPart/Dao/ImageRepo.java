package com.rythmos.SpringMultiPart.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rythmos.SpringMultiPart.model.Image;

public interface ImageRepo extends JpaRepository<Image,Integer>{

}
