package com.rythmos.SpringMultiPart.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rythmos.SpringMultiPart.model.Employee;

public interface Repo extends JpaRepository<Employee,Integer>{

	List<Employee> findByName(String name);
	List<Employee> findByMobileNumber(long mobileNumber);
	List<Employee> findByNameAndPassword(String name, String password);

}
