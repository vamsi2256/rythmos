package com.rythmos.SpringMultiPart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaMultipartApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaMultipartApplication.class, args);
	}

}
