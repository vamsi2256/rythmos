package com.rythmos.crud.repository;

import com.rythmos.crud.SERVICE.StudentDto;
import com.rythmos.crud.model.Student;

public interface Task
{
String delete(String id);
String update(String id,String name);
String insert(Student s);
String updateDto(StudentDto s);
}
