package com.rythmos.crud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.rythmos.crud.Dao.Impl;
import com.rythmos.crud.SERVICE.StudentDto;
import com.rythmos.crud.model.Student;

@RestController
public class Direction
{
	@Autowired
	public Impl impl;
	
	@RequestMapping("/delete/{id}")
	public String delete(@PathVariable String id)
	{
		return impl.delete(id);
	}
	
	@RequestMapping("/update")
	public String update(@RequestParam("id") String id,@RequestParam("name") String name)
	{
		return impl.update(id,name);
	}
	@PostMapping("/save")
	public String insert(@RequestBody Student student)
	{
		return impl.insert(student);
	}
	@PutMapping("/updatedto")
	public String updateDto(@RequestBody StudentDto s)
	{
		return impl.updateDto(s);
	}
}
