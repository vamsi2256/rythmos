package com.rythmos.crud.Dao;

import java.sql.Types;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.rythmos.crud.SERVICE.StudentDto;
import com.rythmos.crud.model.Department;
import com.rythmos.crud.model.Student;
import com.rythmos.crud.repository.Task;

@Repository
public class Impl implements Task 
{
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public String delete(String id) {
		String sql="delete from student1 where id='"+id+"'";
		jdbcTemplate.update(sql);
		return "Data deleted";
	}

	@Override
	public String update(String id, String name) {
		String sql="update student1 set name='"+name+"' where id='"+id+"'";
		jdbcTemplate.update(sql);
		return "Data Updated";
	}

	@Override
	public String insert(Student s) {
		String sql="select * from department where dept_name='"+s.getDepartment().getName()+"'";
		List<Department> list=jdbcTemplate.query(sql,new BeanPropertyRowMapper(Department.class));
		if(list.size()>0)
		{
			String str="insert into student values('"+s.getId()+"','"+s.getName()+"','"+s.getMobileNumber()+"','"+s.getEmail()+"','"+s.getPassword()+"','"+list.get(0).getId()+"')";
			jdbcTemplate.update(str);
			return "Data Inserted";
		}
		else
		{
			String str="insert into department values(seq_dept.nextval,'"+s.getDepartment().getName()+"')";
			jdbcTemplate.update(str);
			insert(s);
		}
		return "Data Inserted";
	}

	@Override
	public String updateDto(StudentDto s) {
		String sql="update student set name=?,mobileNumber=?,email=?,password=? where id=?";
		jdbcTemplate.update(sql,new Object[] {s.getName(),s.getMobileNumber(),s.getEmail(),s.getPassword(),s.getId() },new int[] {Types.VARCHAR,Types.BIGINT,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR});
		return "updated";
	}

}
